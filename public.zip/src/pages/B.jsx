import React from 'react'
import { Outlet } from 'react-router-dom'

function B() {
  return (
    <div>



        <Outlet/>
    </div>
  )
}

export default B