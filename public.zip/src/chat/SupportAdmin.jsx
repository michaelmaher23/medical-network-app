import React from 'react'

function SupportAdmin() {
  return (
    <div>SupportAdmin</div>
  )
}

export default SupportAdmin